import React, { useState, useMemo } from 'react';
import { TOPICS_DATA } from '../constants';
import TopicCard from './TopicCard';
import SearchInput from './SearchInput';
import { useDebounce } from '../hooks/useDebounce';

const TopicSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  const filteredTopics = useMemo(() => {
    const lowercasedQuery = debouncedSearchQuery.trim().toLowerCase();
    if (!lowercasedQuery) {
      return TOPICS_DATA;
    }
    return TOPICS_DATA.filter(topic =>
      topic.name.toLowerCase().includes(lowercasedQuery)
    );
  }, [debouncedSearchQuery]);

  return (
    <div className="space-y-8">
      <SearchInput
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        onClear={() => setSearchQuery('')}
      />
      
      {filteredTopics.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTopics.map((topic, index) => (
            <TopicCard 
              key={topic.id} 
              topic={topic} 
              searchQuery={debouncedSearchQuery.trim()}
              index={index}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center text-center py-16 px-4 bg-slate-800 rounded-lg">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-xl font-semibold text-white">No topics found</h3>
          <p className="text-slate-400 mt-2">Try searching for a different keyword or check your spelling.</p>
        </div>
      )}
    </div>
  );
};

export default TopicSearch;
