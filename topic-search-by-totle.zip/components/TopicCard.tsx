
import React from 'react';
import { Topic } from '../types';

interface TopicCardProps {
  topic: Topic;
  searchQuery?: string;
  index: number;
}

const CATEGORY_COLORS: { [key: string]: string } = {
  Physics: 'bg-blue-500/20 text-blue-300 border-blue-400/30',
  Chemistry: 'bg-green-500/20 text-green-300 border-green-400/30',
  Biology: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30',
  'Computer Science': 'bg-purple-500/20 text-purple-300 border-purple-400/30',
  History: 'bg-amber-500/20 text-amber-300 border-amber-400/30',
  Mathematics: 'bg-red-500/20 text-red-300 border-red-400/30',
};

const HighlightedText: React.FC<{text: string; highlight: string}> = ({ text, highlight }) => {
  if (!highlight) {
    return <>{text}</>;
  }
  const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
  return (
    <>
      {parts.map((part, i) =>
        part.toLowerCase() === highlight.toLowerCase() ? (
          <mark key={i} className="bg-cyan-500/30 text-cyan-300 rounded-sm px-0.5" style={{backgroundColor: 'rgba(34, 211, 238, 0.2)', color: '#67e8f9'}}>
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </>
  );
};


const TopicCard: React.FC<TopicCardProps> = ({ topic, searchQuery = '', index }) => {
  const colorClasses = CATEGORY_COLORS[topic.category] || 'bg-slate-700 text-slate-300';

  return (
    <div 
      className="bg-slate-800/50 border border-slate-700 rounded-lg p-5 flex flex-col justify-between group hover:border-cyan-400/50 transition-all duration-300 transform hover:-translate-y-1 animate-card"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div>
        <h3 className="text-lg font-bold text-slate-100 group-hover:text-cyan-400 transition-colors duration-300">
          <HighlightedText text={topic.name} highlight={searchQuery} />
        </h3>
      </div>
      <div className="mt-4">
        <span className={`inline-block px-3 py-1 text-xs font-medium rounded-full border ${colorClasses}`}>
          {topic.category}
        </span>
      </div>
    </div>
  );
};

export default TopicCard;
